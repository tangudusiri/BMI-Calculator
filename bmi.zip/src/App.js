import './App.css';
import BmiCalci from './components/calci';

function App() {
  return (
    <div className="App">
      <BmiCalci/>
    </div>
  );
}

export default App;
